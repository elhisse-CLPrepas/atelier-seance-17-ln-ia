![LN-IA](site/assets/logo-ln-ia.png)

# Sources et crédits

LAB-NUMÉRIQUE-IA · Abderrahman EL HISSE · 20 novembre 2026

## Origine du parcours

Progression adaptée des photographies fournies : bases HTML, éléments HTML, CSS, JavaScript, utilisation de l’IA. La carte a été réorganisée pour distinguer les rôles et les catégories techniques. Le logo LN-IA fourni est utilisé sur l’accueil et dans le guide.

## Rapport OCDE

OCDE (2026), The agentic AI landscape and its conceptual foundations, OECD Artificial Intelligence Papers, n° 56, Éditions OCDE, Paris, https://doi.org/10.1787/396cf758-en.

Synthèse traduite et adaptation pédagogique LN-IA. Le rapport porte sur les agents IA. Il ne constitue pas un manuel de HTML, CSS ou JavaScript.

Sélection de passages, traduction en français, reformulation pour débutants et ajout d’exercices de développement web. Les applications à l’atelier sont des propositions LN-IA.

In the event of any discrepancy between the original work and the translation, only the text of the original work should be considered valid.

En cas de divergence entre l’œuvre originale et la traduction, seul le texte de l’œuvre originale doit être considéré comme faisant foi.

This is an adaptation of an original work by the OECD. The opinions expressed and arguments employed in this adaptation should not be reported as representing the official views of the OECD or of its Member countries.

Ce document est une adaptation d’une œuvre originale de l’OCDE. Les opinions exprimées et les arguments employés dans cette adaptation ne doivent pas être présentés comme représentant les vues officielles de l’OCDE ou de ses pays membres.

Licence : CC BY 4.0 — https://creativecommons.org/licenses/by/4.0/

## Documentation technique

- [HTML — MDN](https://developer.mozilla.org/en-US/docs/Web/HTML) : HTML est un langage de balisage qui décrit le sens et la structure du contenu.

- [CSS — MDN](https://developer.mozilla.org/en-US/docs/Web/CSS) : CSS est un langage de feuilles de style pour la présentation et la mise en page.

- [JavaScript — MDN](https://developer.mozilla.org/en-US/docs/Web/JavaScript) : JavaScript est un langage de programmation utilisé dans le navigateur et dans d’autres environnements.

- [Introduction to Node.js](https://nodejs.org/en/learn/getting-started/introduction-to-nodejs) : Node.js est un environnement d’exécution JavaScript hors du navigateur, et non un langage distinct.

- [React](https://react.dev/) : React se présente comme une bibliothèque de construction d’interfaces par composants.

- [Introduction — Vue](https://vuejs.org/guide/introduction.html) : Vue est un framework et un écosystème progressif, qui suppose des bases HTML/CSS/JavaScript.

- [What is Angular?](https://angular.dev/overview) : Angular est un framework web avec outils, API et bibliothèques intégrés.

- [Bootstrap 5.3 — Introduction](https://getbootstrap.com/docs/5.3/getting-started/introduction/) : Bootstrap fournit styles, grille et composants d’interface. Les compétences HTML/CSS restent nécessaires.

- [Tailwind CSS](https://tailwindcss.com/) : Tailwind CSS est un framework CSS fondé sur des classes utilitaires.

- [jQuery](https://jquery.com/) : jQuery est une bibliothèque JavaScript pour manipulation du DOM, événements et requêtes Ajax. Elle n’est pas nécessaire au parcours de base.

- [REST — thèse de Roy Fielding, chapitre 5](https://ics.uci.edu/~fielding/pubs/dissertation/rest_arch_style.htm) : REST est un style architectural pour systèmes hypermédias distribués, pas un langage de programmation.

- [Introduction to GraphQL](https://graphql.org/learn/introduction/) : GraphQL est un langage de requête pour API et un environnement d’exécution côté serveur. Il ne désigne pas une base de données.

- [PostgreSQL — About](https://www.postgresql.org/about/) : PostgreSQL est un système de gestion de base de données objet-relationnelle utilisant SQL.

- [MySQL Community Edition](https://www.mysql.com/products/community/) : MySQL est un système de gestion de base de données, historiquement relationnel, qui comprend aussi des fonctions documentaires.

- [MongoDB — Database Manual](https://www.mongodb.com/docs/manual/introduction/) : MongoDB est une base de données orientée documents.

- [Vite — Getting Started](https://vite.dev/guide/) : Vite est un outil de développement et de construction. Il n’est ni un langage ni un framework d’interface.

- [OCDE — The agentic AI landscape and its conceptual foundations](https://doi.org/10.1787/396cf758-en) : Rapport fourni par l’utilisateur. Source des traductions et adaptations sur autonomie, agents, coordination et vérification.

## Dépendances

Bootstrap 5.3.9 : licence MIT, copie conservée dans application/THIRD-PARTY-LICENSES.txt. Vite 8.3.8 : outil de construction, licence MIT. Les dépendances ne sont pas incluses dans node_modules ; npm ci les installe selon package-lock.json.
import test from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import {readFileSync} from 'node:fs';
import {initialState,normalizeState,scoreQuiz,makeDocument,projectDocument} from '../src/core.js';

const content=JSON.parse(readFileSync(new URL('../src/curriculum.json',import.meta.url),'utf8'));

test('un bilan exporté puis restauré conserve le travail du participant',()=>{
  const original=initialState();
  original.completed=['intro','html'];
  original.project={name:'Atelier Élodie',audience:'Débutants',goal:'Lire une fiche',action:'Consulter la fiche'};
  original.draft={html:'<h1>Élodie & Samira</h1>',css:'h1 { color: navy; }',js:'document.body.dataset.test = "ok";'};
  original.notes='Observation : le lien fonctionne avec Entrée.';
  original.checks={'0':true,'1':false};
  original.quizAnswers={'0':0,'1':2};
  original.quizSubmitted=true;
  const restored=normalizeState(JSON.parse(JSON.stringify(original)));
  assert.deepEqual(restored,original);
  restored.completed.push('css');
  restored.draft.html='Nouvelle version';
  assert.deepEqual(original.completed,['intro','html']);
  assert.match(original.draft.html,/Élodie/);
});

test('des activités répétées dans un import ne gonflent pas la progression',()=>{
  const s=normalizeState({completed:['html','html','inconnue','css','intro','html']});
  assert.deepEqual(s.completed,['html','css','intro']);
});

test('un import écarte les validations et réponses impossibles',()=>{
  const s=normalizeState({
    checks:{0:true,1:'false',2:0,8:true,unknown:true},
    quizAnswers:{0:0,1:'1',2:99,3:-1,4:1.5,12:2,unknown:0},
    project:{name:'Mon projet',extra:'Ce champ ne fait pas partie du projet'},
    draft:{html:'<p>Texte</p>',css:[],js:null,extra:'Pas une zone de code'}
  });
  assert.deepEqual(s.checks,{'0':true});
  assert.deepEqual(s.quizAnswers,{'0':0});
  assert.deepEqual(Object.keys(s.project).sort(),['action','audience','goal','name']);
  assert.deepEqual(s.draft,{html:'<p>Texte</p>',css:'',js:''});
});

test('un import ne modifie pas le prototype global',()=>{
  const raw=JSON.parse('{"draft":{"__proto__":{"polluted":true},"html":"<p>OK</p>"},"project":{"constructor":"bad"},"checks":{"prototype":true}}');
  const s=normalizeState(raw);
  assert.equal({}.polluted,undefined);
  assert.equal(Object.hasOwn(s.draft,'__proto__'),false);
  assert.equal(Object.hasOwn(s.project,'constructor'),false);
  assert.equal(Object.hasOwn(s.checks,'prototype'),false);
  assert.equal(s.draft.html,'<p>OK</p>');
});

test('le quiz distingue réponses correctes, absentes et valeurs non valides',()=>{
  assert.equal(scoreQuiz({},content.quiz),0);
  const allCorrect=Object.fromEntries(content.quiz.map((q,i)=>[i,q.correct]));
  assert.equal(scoreQuiz(allCorrect,content.quiz),12);
  const mixed={...allCorrect,0:undefined,1:String(content.quiz[1].correct),2:99};
  assert.equal(scoreQuiz(mixed,content.quiz),9);
});

test('un intitulé de projet contenant du HTML reste du texte dans le fichier exporté',()=>{
  const doc=projectDocument({name:'<img src=x onerror=alert(1)>',audience:'A & B',goal:'Lire "la fiche"',action:'<script>alert(2)</script>'});
  assert.ok(doc.startsWith('<!doctype html>'));
  assert.ok(doc.includes('lang="fr"'));
  assert.ok(doc.includes('&lt;img src=x onerror=alert(1)&gt;'));
  assert.ok(doc.includes('A &amp; B'));
  assert.ok(!doc.includes('<img src=x'));
  assert.ok(!doc.includes('<script>alert(2)</script>'));
  assert.ok(doc.includes('href="#fiche"'));
  assert.ok(doc.includes('id="fiche"'));
});

test('les balises de fermeture dans une chaîne JavaScript ne quittent pas son bloc',()=>{
  const payload='</script><script>globalThis.injected = true</script>';
  const doc=makeDocument({html:'<main>Essai</main>',css:'.sample::after { content: "</style>"; }',js:'globalThis.literal = '+JSON.stringify(payload)+';'});
  const scripts=[...doc.matchAll(/<script>([\s\S]*?)<\/script>/gi)];
  assert.equal(scripts.length,1);
  const context={};
  vm.runInNewContext(scripts[0][1],context);
  assert.equal(context.literal,payload);
  assert.equal(context.injected,undefined);
  assert.equal((doc.match(/<\/style>/gi)||[]).length,1);
});

test('le document d’aperçu interdit les connexions et ressources réseau usuelles',()=>{
  const doc=makeDocument({html:'<p>Test</p>',css:'',js:''},true);
  assert.ok(doc.includes('Content-Security-Policy'));
  assert.ok(doc.includes("connect-src 'none'"));
  assert.ok(doc.includes('img-src data: blob:'));
  assert.ok(doc.includes("form-action 'none'"));
  assert.ok(!doc.includes('https://'));
});

test('l’exercice JavaScript répond aux saisies vide, accentuée et contenant des balises',()=>{
  const a=content.activities.find(x=>x.id==='js');
  const listeners={};
  const elements={
    '#accueil':{addEventListener:(name,fn)=>listeners[name]=fn},
    '#prenom':{value:''},'#message':{textContent:''},'#fiche':{hidden:true}
  };
  vm.runInNewContext(a.js,{document:{querySelector:s=>elements[s]}});
  for(const value of ['Samira','','   ','Élodie','<b>Samira</b>']){
    elements['#prenom'].value=value;
    elements['#fiche'].hidden=true;
    let prevented=false;
    listeners.submit({preventDefault(){prevented=true;}});
    assert.equal(prevented,true);
    assert.equal(elements['#fiche'].hidden,false);
    const expected=value.trim()?'Bonjour '+value.trim()+', voici les deux points à examiner.':'Bienvenue. Voici les deux points à examiner.';
    assert.equal(elements['#message'].textContent,expected);
  }
});

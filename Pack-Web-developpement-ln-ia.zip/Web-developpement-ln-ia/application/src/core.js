export const escapeHTML = (value='') => String(value).replace(/[&<>"']/g, ch=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[ch]));
export const scoreQuiz=(answers,questions)=>questions.reduce((sum,q,i)=>sum+(answers[i]===q.correct?1:0),0);
export const initialState=()=>({version:1,exampleId:'intro',completed:[],checks:{},notes:'',draft:{html:'',css:'',js:''},project:{name:'Roue Libre',audience:'Cyclistes débutants',goal:'Comprendre deux contrôles avant de partir',action:'Lire la fiche de contrôle'},quizAnswers:{},quizSubmitted:false});
export function normalizeState(raw){
 const s=initialState();if(!raw||typeof raw!=="object")return s;
 if(Array.isArray(raw.completed))s.completed=[...new Set(raw.completed.filter(x=>['intro','html','elements','css','js','ia'].includes(x)))];
 if(typeof raw.notes==='string')s.notes=raw.notes.slice(0,100000);
 if(raw.draft&&typeof raw.draft==='object')for(const k of ['html','css','js'])if(typeof raw.draft[k]==='string')s.draft[k]=raw.draft[k].slice(0,500000);
 if(raw.project&&typeof raw.project==='object')for(const k of ['name','audience','goal','action'])if(typeof raw.project[k]==='string')s.project[k]=raw.project[k].slice(0,240);
 if(raw.checks&&typeof raw.checks==='object')for(let i=0;i<8;i++)if(typeof raw.checks[i]==='boolean')s.checks[i]=raw.checks[i];
 if(raw.quizAnswers&&typeof raw.quizAnswers==='object')for(let i=0;i<12;i++){const v=raw.quizAnswers[i];if(Number.isInteger(v)&&v>=0&&v<4)s.quizAnswers[i]=v;}
 if(['intro','html','elements','css','js','ia'].includes(raw.exampleId))s.exampleId=raw.exampleId;
 s.quizSubmitted=raw.quizSubmitted===true;
 return s;
}
export function makeDocument({html='',css='',js=''},sandbox=false){
 const safeCSS=css.replace(/<\/style/gi,'<\\/style');
 const safeJS=js.replace(/<\/script/gi,'<\\/script');
 const csp=sandbox?'<meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data: blob:; font-src \'none\'; connect-src \'none\'; form-action \'none\'; base-uri \'none\';">':'';
 const bridge=sandbox?`<script>window.addEventListener('error',e=>parent.postMessage({kind:'lnia-preview-error',message:e.message},'*'));<\/script>`:'';
 return '<!doctype html>\n<html lang="fr"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ma page web LN-IA</title>'+csp+bridge+'<style>'+safeCSS+'</style></head><body>'+html+'<script>'+safeJS+'<\/script></body></html>';
}
export function projectDocument(p){return makeDocument({html:`<header><p>Projet pédagogique fictif</p><h1>${escapeHTML(p.name)}</h1><p>${escapeHTML(p.goal)}</p><a class="action" href="#fiche">${escapeHTML(p.action)}</a></header><main><section id="fiche"><h2>La fiche de mon projet</h2><p>Public : ${escapeHTML(p.audience)}</p><p>À compléter avec vos informations vérifiées et vos sources.</p><ul><li>Premier point à expliquer.</li><li>Deuxième point à expliquer.</li></ul></section></main><footer>Projet construit avec LN-IA</footer>`,css:'body{font-family:system-ui,sans-serif;line-height:1.6;max-width:54rem;margin:0 auto;padding:2rem;color:#10264b;background:#f4f7fb}header{padding:2rem 0}h1{font-size:clamp(2rem,8vw,4rem)}.action{display:inline-block;background:#10264b;color:white;padding:.9rem 1.2rem;border-radius:.5rem}a:focus-visible{outline:3px solid #976e15;outline-offset:4px}section{margin:2rem 0;padding:1.5rem;background:white;border:1px solid #c7d1df}footer{margin-top:2rem}'});}

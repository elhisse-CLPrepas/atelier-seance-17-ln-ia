# Application Web développement LN-IA

Sources de l’atelier interactif. Voir le guide et COMMENCER-ICI.md à la racine du pack.

```sh
npm ci
npm run dev
npm test
npm run build
npm run pack
```

Vite 8.3.8, Bootstrap 5.3.9, JavaScript natif. Le build utilise des chemins relatifs. `public/docs` contient les documents téléchargeables. `scripts/package.mjs` produit une version HTML portable, le site construit et les six exemples dans `../pack/`.

Les données de progression restent dans le navigateur. Les exemples s’exécutent dans une iframe avec `sandbox="allow-scripts allow-forms"`, sans `allow-same-origin`, et une politique CSP qui bloque les requêtes de scripts et les envois de formulaire. Le code peut modifier sa propre page et naviguer sa propre iframe. Les saisies du formulaire d’exemple sont affichées avec `textContent`.

Tests : restauration de bilan, déduplication, filtrage des imports, protection des prototypes, correction du quiz, échappement des textes de projet, encapsulation du JavaScript, CSP et comportements du formulaire.

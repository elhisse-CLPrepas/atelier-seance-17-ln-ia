import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {makeDocument} from '../src/core.js';
const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.resolve(root,'..','pack');
fs.mkdirSync(out,{recursive:true});
fs.cpSync(path.join(root,'dist'),path.join(out,'site'),{recursive:true});
let html=fs.readFileSync(path.join(root,'dist/index.html'),'utf8');
html=html.replace(/<script type="module"[^>]*src="([^"]+)"[^>]*><\/script>/,(_,src)=>{
 let js=fs.readFileSync(path.join(root,'dist',src),'utf8').replace(/<\/script/gi,'<\\/script');
 return '<script>window.LNIA_ASSET_BASE="site/";\n'+js+'</script>';
});
html=html.replace(/<link rel="stylesheet"[^>]*href="([^"]+)"[^>]*>/,(_,href)=>'<style>'+fs.readFileSync(path.join(root,'dist',href),'utf8')+'</style>');
html=html.replaceAll('src="./assets/','src="site/assets/').replaceAll('href="./assets/','href="site/assets/');
// The compiled entry was placed in head by Vite. Run it after the document body exists.
const script=html.match(/<script>window\.LNIA_ASSET_BASE=[\s\S]*?<\/script>/)?.[0];
if(!script)throw Error('Script portable introuvable');
html=html.replace(script,'').replace('</body>',script+'\n</body>');
fs.writeFileSync(path.join(out,'OUVRIR-APPLICATION.html'),html);
const examples=path.join(out,'exemples');fs.mkdirSync(examples,{recursive:true});
const content=JSON.parse(fs.readFileSync(path.join(root,'src/curriculum.json'),'utf8'));
for(const [i,a] of content.activities.entries()){
 const dir=path.join(examples,String(i).padStart(2,'0')+'-'+a.id);fs.mkdirSync(dir,{recursive:true});
 fs.writeFileSync(path.join(dir,'index.html'),makeDocument(a));
 fs.writeFileSync(path.join(dir,'contenu.html'),a.html);fs.writeFileSync(path.join(dir,'style.css'),a.css);fs.writeFileSync(path.join(dir,'script.js'),a.js);
 fs.writeFileSync(path.join(dir,'consigne.md'),'# '+a.title+'\n\n'+a.objective+'\n\n'+a.task+'\n\n## Vérifier\n\n'+a.success.map(s=>'- '+s).join('\n')+'\n\n## Correction\n\n'+a.correction+'\n');
}
console.log('Site, application portable et exemples créés dans '+out);

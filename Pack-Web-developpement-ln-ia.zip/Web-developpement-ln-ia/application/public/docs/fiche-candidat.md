![LN-IA](../assets/logo-ln-ia.png)

# Ma fiche de production web LN-IA

Nom du candidat :
Date :
Projet personnel ou cas fictif :

## Mon intention

Public :
Besoin du public :
Message principal :
Action unique proposée au lecteur :
Informations vérifiées et sources :

## Ma production

Fichier HTML final :
Titre de la page :
Structure HTML que je peux expliquer :
Règle CSS que j’ai modifiée :
Événement JavaScript que j’ai testé :

## Mes tests

| Test réellement effectué | Résultat attendu | Résultat observé | Correction |
| --- | --- | --- | --- |
| Navigation au clavier | | | |
| Écran étroit | | | |
| Saisie vide puis valide | | | |
| Saisie contenant des balises | | | |
| Lien principal | | | |

## Ma contribution humaine

Prompt utilisé si applicable :
Proposition de l’IA :
Ce que j’ai contrôlé :
Ce que j’ai corrigé :
Pourquoi cette décision :

## Mes preuves

- [ ] Page HTML enregistrée et ouverte dans un navigateur.
- [ ] Capture ou description de la version avant correction.
- [ ] Résultats des tests après correction.
- [ ] Bilan exporté depuis l’application.
- [ ] Une notion à retravailler et ma prochaine action.

LAB-NUMÉRIQUE-IA · Abderrahman EL HISSE · 20 novembre 2026 · v1.0

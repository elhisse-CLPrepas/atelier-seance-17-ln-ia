![LN-IA](../assets/logo-ln-ia.png)

# Développement Web · LN-IA

Guide d’animation et progression pédagogique. Version du 20 novembre 2026.

## Intention

Passer de l’observation d’une page à une production que l’on comprend et que l’on peut vérifier. Le participant construit une page utile. Il explique le rôle de HTML, CSS et JavaScript. Il situe cette page dans un échange entre un navigateur et un serveur. Il utilise l’IA pour proposer et corriger sans lui déléguer la validation.

Public : débutants francophones, enseignants, formateurs et candidats au Challenge 100 Jours.

Prérequis : ouvrir un navigateur, saisir du texte et gérer un dossier. La connaissance préalable d’un langage de programmation n’est pas requise.

Durée proposée : trois heures. Les activités peuvent être réparties en deux séances de 90 minutes ou suivies à son rythme. Les durées sont des repères d’animation.

Matériel : un ordinateur, un navigateur récent et l’application locale. Un éditeur de texte est utile pour prolonger la pratique. Un service d’IA est facultatif. L’application fournit les exemples et les prompts sans exiger de compte IA.

## Activité d’introduction : de l’observation à l’hypothèse

Question de départ : que se passe-t-il quand vous ouvrez une page Web ?

Présentez une page simple. Demandez au groupe de repérer trois éléments : un contenu, une mise en forme et une réaction à une action. Chacun écrit une hypothèse avant la démonstration.

Le groupe suit ensuite la simulation locale de l’application. Le modèle comprend le navigateur, une requête HTTP, un serveur et une réponse. Il est volontairement simplifié. Il ne montre pas toutes les étapes possibles, notamment DNS, TLS, cache, redirections ou chargements multiples. Les étapes affichées ne sont pas la preuve d’un appel réseau effectué par l’application.

Les participants associent ensuite trois besoins à trois technologies : un titre avec HTML, une couleur avec CSS, une réaction à la soumission d’un formulaire avec JavaScript.

Production attendue : un schéma légendé et une explication de six lignes. Chaque participant conserve son hypothèse de départ et sa reformulation finale.

Question de vérification : une page avec un bouton peut-elle fonctionner sans base de données ? Oui. Le navigateur peut exécuter un comportement local. Une base ou un service distant devient pertinent lorsque le besoin l’exige, par exemple pour partager des données entre utilisateurs.

## Plan d’animation de trois heures

| Temps | Activité | Action du participant | Trace produite |
|---|---|---|---|
| 00:00–00:15 | Introduction | Prévoir, observer la simulation, expliquer | Hypothèse et schéma navigateur–serveur |
| 00:15–00:35 | HTML | Structurer un contenu avec des titres, sections et listes | Première structure de page |
| 00:35–00:55 | Éléments HTML | Insérer une image et un lien utile | Image décrite et action principale fonctionnelle |
| 00:55–01:20 | CSS | Organiser, mettre en forme, vérifier une largeur réduite | Version lisible sur deux tailles d’écran |
| 01:20–01:50 | JavaScript | Personnaliser un message et tester les saisies | Interaction et tableau de tests |
| 01:50–02:15 | IA | Formuler un brief, examiner une proposition, corriger | Prompt, comparaison et décision humaine |
| 02:15–02:40 | Mini-projet personnel | Adapter la page à un besoin choisi | Page personnelle et fiche de preuve |
| 02:40–03:00 | Bilan | Tester les acquis, faire relire, préparer la suite | Quiz commenté et plan d’amélioration |

Option en deux rencontres : la première s’arrête après CSS et dix minutes de retour sur les productions. La seconde reprend avec un rappel de dix minutes, puis JavaScript, IA, mini-projet et bilan. Les temps d’échanges peuvent être adaptés au groupe.

## Fil rouge : Roue Libre

Roue Libre est un cas fictif. La page informe sur deux points à examiner avant un départ à vélo : les pneus et les freins. L’action principale est « Lire la fiche de contrôle ».

Le cas apprend à aligner une annonce, un contenu et une action. Il ne constitue pas un manuel de réparation ni une révision complète d’un vélo. Ne pas ajouter de prix, de réservation, de témoignage ou de promesse absents du brief.

Le bouton et le lien de la page peuvent évoluer selon l’exercice. Dans l’activité JavaScript, la même intention passe par un formulaire qui affiche la fiche et un message personnalisé. Le prénom ou pseudonyme est facultatif. Il n’est ni envoyé à un serveur ni enregistré durablement par l’exemple.

Les commandes pédagogiques de l’application, comme lancer l’aperçu ou afficher une correction, appartiennent à l’outil d’apprentissage. Elles ne constituent pas des actions supplémentaires à ajouter à la page finale du participant.

## Activité 1 : structurer avec HTML

Le participant repère un titre principal, un paragraphe, une liste et une section. Il transforme ensuite l’exemple en fiche personnelle.

Consigne : créer un titre principal, une introduction de deux phrases, deux sections titrées et une liste. Le contenu doit rester compréhensible sans mise en forme.

Points d’attention : HTML est un langage de balisage. Les titres structurent le document. Ils ne servent pas seulement à modifier la taille du texte. Les éléments sont correctement imbriqués. Un document complet comprend une enveloppe avec doctype, html lang="fr", head et body. L’éditeur de l’application fournit cette enveloppe pour les fragments proposés.

Question de retour : si l’on retire les couleurs et les espacements, peut-on encore comprendre l’ordre des idées ?

Preuve : copie du HTML et capture de son aperçu.

## Activité 2 : relier une image et une destination

Consigne : ajouter une illustration utile, un texte alternatif adapté au contexte et un lien principal dont la destination existe.

Le participant compare le libellé « Cliquez ici » avec « Lire la fiche de contrôle ». Il explique lequel annonce mieux le résultat attendu. Il vérifie la correspondance entre href="#fiche" et id="fiche".

L’image du laboratoire est un SVG intégré sous forme d’adresse de données. Ce choix évite la dépendance à un hébergeur d’images. Il ne dispense pas d’apprendre les chemins de fichiers pour un site comportant plusieurs ressources.

Test : atteindre le lien avec Tab, puis l’activer avec Entrée.

Preuve : image et lien fonctionnels, plus une phrase qui justifie l’action retenue.

## Activité 3 : organiser avec CSS

Consigne : choisir deux couleurs principales, une typographie lisible, des espacements réguliers et une largeur qui s’adapte à l’écran.

Démarche : identifier le sélecteur, modifier une propriété, observer l’effet, expliquer le résultat. Ne pas changer plusieurs propriétés au hasard. Tester le texte long et une largeur réduite.

Le participant ne se limite pas à une impression visuelle. Il contrôle le contraste avec un outil approprié et conserve un focus clavier visible. Une information importante reste exprimée par du texte, même lorsqu’une couleur l’accompagne.

Preuve : deux captures ou deux observations documentées, sur écran large et étroit, avec une correction éventuelle.

## Activité 4 : saisir, agir, observer

Consigne : afficher un accueil personnalisé et révéler la fiche quand le formulaire est envoyé.

Les fonctions centrales sont querySelector, addEventListener et textContent. Le participant observe aussi submit, preventDefault, trim et hidden. Le passage par submit permet de traiter la touche Entrée et le clic sur le bouton.

| Saisie | Résultat attendu |
|---|---|
| Samira | Message commençant par « Bonjour Samira » et fiche visible |
| Champ vide | Message commençant par « Bienvenue » et fiche visible |
| Espaces seuls | Même traitement qu’un champ vide |
| Prénom accentué | Accents conservés dans le message |
| Texte contenant des balises | Caractères affichés comme du texte, sans mise en forme HTML |

Le participant complète une colonne « résultat observé ». Une case de test n’est validée qu’après l’essai. Si l’aperçu ne réagit pas, il vérifie les identifiants HTML, les sélecteurs JavaScript et la console du navigateur lorsqu’elle est disponible.

Preuve : tableau de tests et explication d’une ligne de JavaScript.

## Activité 5 : utiliser l’IA en gardant la maîtrise

Consigne : rédiger un brief, obtenir une proposition, examiner le code, tester et effectuer une correction justifiée.

Le brief contient le public, l’objectif, les informations disponibles, une action principale et des critères de réussite. Les prompts réutilisables de l’application servent à créer, expliquer, corriger et contrôler.

La relecture porte sur le contenu et sur le comportement. Le participant repère les appels réseau, les dépendances, les données saisies et les destinations des liens. Il distingue les constats lisibles dans le code des résultats qui nécessitent un essai dans le navigateur.

Un assistant qui propose du code n’est pas automatiquement un système agentique. La partie documentaire fondée sur le PDF fourni développe les notions utiles aux permissions, à l’orchestration et aux contrôles. Les affirmations concernant ce PDF doivent renvoyer aux pages réellement consultées. Ce document pédagogique ne lui attribue pas un cours HTML ou CSS qu’il ne contient pas.

Exemple de décision humaine : remplacer une promesse de « révision complète » par une annonce limitée à deux points à examiner. Le participant conserve la phrase avant correction, la phrase après correction et la justification.

Preuve : brief, prompt, code retenu, résultats de tests et correction commentée.

## Mini-projet personnel

Choisir un sujet connu et limiter le périmètre. Exemples : présenter un atelier et ouvrir son programme, expliquer une méthode et consulter sa fiche, annoncer une ressource et accéder à son contenu.

Le projet conserve une action principale. Son contenu apporte une information réelle ou clairement identifiée comme fictive. Le participant dispose d’un titre, de sections, d’une image pertinente ou décorative correctement traitée, d’une présentation responsive et d’une interaction qu’il peut expliquer.

La publication vient après les vérifications. Le dossier local constitue déjà une production. Un site statique peut être publié sur un hébergement adapté sans base de données ni application serveur personnalisée. Les comptes utilisateurs, les formulaires partagés et les services distants demandent une conception supplémentaire.

## Portfolio et fiche de preuve

Dossier conseillé : mon-premier-site-ln-ia.

Contenu attendu :

- brief-projet.md : public, objectif, informations disponibles et action principale.
- index.html : version du document HTML.
- style.css : présentation séparée si le projet est organisé en plusieurs fichiers.
- script.js : comportement expliqué, si une interaction est nécessaire.
- journal-tests.md : action effectuée, résultat attendu, résultat observé et statut.
- decision-humaine.md : une correction avant/après et sa justification.
- sources.md : ressources, auteurs et adresses utilisés.

Le format d’export de l’application peut regrouper les styles et le script dans un seul fichier HTML. Cette organisation convient à l’apprentissage et au partage d’un petit exemple. La séparation en plusieurs fichiers est une étape suivante.

Modèle de preuve :

| Élément | À renseigner |
|---|---|
| Projet et version | Nom, date et version |
| Lecteur | Public visé |
| Objectif | Information utile ou service rendu |
| Action principale | Libellé et destination |
| Proposition initiale | Résumé ou extrait |
| Correction humaine | Modification et justification |
| Tests | Attendu, observé, statut |
| Suite | Une amélioration prioritaire |

## Validation de l’atelier

Le participant peut :

- expliquer le rôle de HTML, CSS et JavaScript avec un exemple ;
- distinguer navigateur, serveur, API et base de données ;
- montrer un lien fonctionnel et une alternative textuelle adaptée ;
- utiliser sa page au clavier et vérifier sa largeur réduite ;
- expliquer et tester une interaction simple ;
- distinguer une proposition d’IA d’un résultat testé ;
- présenter une correction qu’il a décidée et justifiée.

Le quiz est un outil de retour sur les notions. Il ne remplace pas l’examen de la production. Chaque réponse erronée doit conduire à un exemple ou à un nouvel essai.

## Amélioration du schéma initial

Conserver la distinction entre l’interface côté navigateur et les traitements côté serveur. Ajouter les échanges HTTP et la possibilité d’un site statique.

Classer les technologies par rôle : HTML pour le balisage, CSS pour les styles et JavaScript pour la programmation. Node.js est un environnement d’exécution de JavaScript. React est une bibliothèque d’interface. Angular et Vue fournissent des cadres de construction d’interface. Bootstrap et Tailwind CSS concernent principalement la présentation. jQuery est une bibliothèque JavaScript.

Situer REST comme style architectural et GraphQL comme langage de requête pour API avec un modèle d’exécution. Placer PostgreSQL, MySQL et MongoDB dans la partie stockage. Ajouter Git pour le suivi des versions, Vite pour le développement et la construction, puis les tests et le déploiement.

Les participants n’ont pas à apprendre tous les outils du schéma. Le parcours commence par HTML, CSS et JavaScript. Chaque outil complémentaire répond ensuite à un besoin identifié.

## Prolongements

Explorer le panneau Réseau du navigateur sur un site publié. Observer une requête, son code d’état et son type de ressource. Comparer cet échange réel avec la simulation pédagogique.

Organiser les fichiers d’un projet, utiliser Git pour conserver les versions et construire une application avec Vite. Tester les chemins des images et des styles avant de publier sous un sous-répertoire.

Découvrir une API à partir d’un exemple explicitement simulé ou d’un service documenté. Séparer l’interface de la logique de données. Aborder ensuite la validation serveur, l’authentification et le stockage lorsqu’un projet en a besoin.

Ces prolongements complètent les cinq activités initiales. Ils ne sont pas des prérequis pour réussir la première page.

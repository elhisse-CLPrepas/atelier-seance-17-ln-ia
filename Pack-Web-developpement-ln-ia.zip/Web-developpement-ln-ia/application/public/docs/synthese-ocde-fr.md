![LN-IA](../assets/logo-ln-ia.png)

# Synthèse traduite et adaptation pédagogique LN-IA

Le paysage de l’IA agentique et ses fondements conceptuels

Synthèse traduite et adaptation pédagogique LN-IA. Le rapport porte sur les agents IA. Il ne constitue pas un manuel de HTML, CSS ou JavaScript.

OCDE (2026), The agentic AI landscape and its conceptual foundations, OECD Artificial Intelligence Papers, n° 56, Éditions OCDE, Paris, https://doi.org/10.1787/396cf758-en.

Les références désignent la pagination imprimée. La page imprimée 10 correspond à la page 11 du fichier PDF.

## Définir un objectif observable — p. 9-10

Le rapport distingue objectifs, entrées et sorties d’un système IA. Une consigne précise le résultat attendu et les données nécessaires.

Application proposée par LN-IA : Demander une page présentant un atelier avec un titre, trois informations vérifiées et un seul lien d’action. Fournir ces informations au lieu de laisser le système les inventer.

## Séparer suggestion et action — p. 10

Un système peut recommander une action, attendre une approbation ou agir avec davantage d’autonomie. Le niveau d’autonomie dépend de sa conception et de son déploiement.

Application proposée par LN-IA : L’IA propose une modification HTML. Le participant lit le changement, teste le rendu et décide de le conserver. La publication reste une étape distincte.

## Reconnaître un agent IA — p. 14-15

Le rapport retient comme traits communs l’observation d’un environnement, la poursuite d’objectifs et la capacité d’agir avec une certaine autonomie, éventuellement au moyen d’outils. Les définitions ne sont pas totalement stabilisées.

Application proposée par LN-IA : Un texte de code proposé dans une conversation est une production. Un outil qui lit des fichiers, les modifie puis lance les tests intervient dans un environnement de travail.

## Comprendre la coordination agentique — p. 19-20, 23

Dans l’analyse du rapport, l’IA agentique met davantage l’accent sur la décomposition des tâches, la délégation, la coordination entre agents et la poursuite d’objectifs sur des durées plus longues.

Application proposée par LN-IA : Pour comprendre le processus, répartir une tâche en structure HTML, présentation CSS et contrôle des interactions. Cette décomposition pédagogique ne transforme pas à elle seule une application en système agentique.

## Prévoir une boucle de vérification — p. 15, 28

Le rapport décrit l’adaptation à des entrées et contextes changeants. Il situe aussi le suivi, l’évaluation et la comparaison des performances parmi les pistes de développement fiable.

Application proposée par LN-IA : Observer le résultat, relever un défaut, modifier une seule chose puis refaire le même test. Conserver le constat avant/après dans le portfolio.

## Comprendre le rôle des interfaces — p. 14, 24

Les agents peuvent utiliser des outils à travers des API ou des interfaces. La coordination nécessite aussi des infrastructures et des protocoles partagés.

Application proposée par LN-IA : Distinguer un bouton dans le navigateur, une requête vers une API et la réponse reçue. Une interface ne garantit pas à elle seule les permissions nécessaires.

## Contrôler exactitude et données — p. 25-27

Les résultats d’enquête repris dans le rapport signalent des préoccupations sur la sécurité, la confidentialité et l’exactitude. Les auteurs précisent que ces observations sont indicatives et ne couvrent pas tous les développeurs.

Application proposée par LN-IA : Employer des exemples fictifs dans l’exercice. Vérifier les liens et les affirmations. Ne pas intégrer une clé d’API privée dans le code envoyé au navigateur.

## Garder une responsabilité explicite — p. 23-24, 28

L’approche sociotechnique relie capacités techniques, interactions, contexte et valeurs. La discussion finale cite notamment la responsabilité, l’explicabilité et la transparence.

Application proposée par LN-IA : Le candidat indique ce que l’IA a proposé, ce qu’il a corrigé et les tests qu’il a exécutés. Il doit pouvoir expliquer la page qu’il livre.

## Courts extraits traduits

Original : Autonomy generally refers to a system’s capacity to act without direct human involvement.

Traduction LN-IA : L’autonomie désigne généralement la capacité d’un système à agir sans intervention humaine directe.

Page imprimée : 10

Original : not all AI agents are part of an agentic AI system.

Traduction LN-IA : Tous les agents IA ne font pas partie d’un système d’IA agentique.

Page imprimée : 28

## Attribution et modifications

Sélection de passages, traduction en français, reformulation pour débutants et ajout d’exercices de développement web. Les applications à l’atelier sont des propositions LN-IA.

In the event of any discrepancy between the original work and the translation, only the text of the original work should be considered valid.

En cas de divergence entre l’œuvre originale et la traduction, seul le texte de l’œuvre originale doit être considéré comme faisant foi.

This is an adaptation of an original work by the OECD. The opinions expressed and arguments employed in this adaptation should not be reported as representing the official views of the OECD or of its Member countries.

Ce document est une adaptation d’une œuvre originale de l’OCDE. Les opinions exprimées et les arguments employés dans cette adaptation ne doivent pas être présentés comme représentant les vues officielles de l’OCDE ou de ses pays membres.

Licence : CC BY 4.0 — https://creativecommons.org/licenses/by/4.0/
![LN-IA](site/assets/logo-ln-ia.png)

# Contrôles réalisés

Version 1.0 — 20 novembre 2026.

- Construction Vite réussie avec dépendances verrouillées.
- Neuf tests automatisés réussis : sauvegarde/restauration, import, score, exports et formulaire.
- Navigation des rubriques vérifiée dans Chrome.
- Schéma interactif : sélection des notions et explication affichée.
- Laboratoire : changement d’exemple, aperçu, formulaire à saisie vide et balises affichées comme texte.
- Quiz : zéro réponse donne 0/12 et douze réponses correctes donnent 12/12.
- Projet : champs et checklist conservés après rechargement.
- Affichage d’accueil et navigation vérifiés dans un cadre de 390 pixels de largeur.
- Version portable vérifiée en HTTP avec son JavaScript et ses styles intégrés. Elle ne comporte aucun import de module à charger depuis file://. L’ouverture directe locale dépend des règles du navigateur, notamment pour la sauvegarde.
- Guide Word : 26 pages rendues et inspectées. Audit structurel d’accessibilité sans anomalie relevée.
- Archive : intégrité ZIP, absence de node_modules et présence des ressources locales contrôlées.

La validation des exercices est une autoévaluation. L’application n’est ni un service de certification ni un générateur IA connecté. Les cas présentés sont fictifs et les contrôles du participant doivent porter sur ses propres résultats.

![LN-IA](site/assets/logo-ln-ia.png)

# Développement web LN-IA

Un parcours pour comprendre le fonctionnement du Web et construire votre première page. Public débutant. Durée indicative : 3 heures, fractionnables. Abderrahman EL HISSE — LAB-NUMÉRIQUE-IA. Version 1.0 du 20 novembre 2026.

## Ouvrir l’application sans installation

1. Décompressez entièrement le ZIP dans un dossier.
2. Ouvrez `OUVRIR-APPLICATION.html` avec Chrome, Edge ou Firefox.
3. Commencez par l’activité d’ouverture puis suivez les cinq activités.
4. Dans le laboratoire, chargez un exemple, modifiez le code et lancez l’aperçu.
5. Exportez votre page HTML et votre bilan depuis « Mon projet ».

Gardez ensemble le fichier d’ouverture et le dossier `site`. Le logo, le guide et le schéma sont chargés depuis ce dossier. Les activités et les fonctions principales fonctionnent sans Internet. Les liens vers les sources externes nécessitent une connexion.

Si votre navigateur limite l’enregistrement local des fichiers, utilisez l’export JSON. Il contient le code, la progression, le projet et les observations. Vous pouvez le restaurer dans « Ressources ». Il n’y a pas de compte utilisateur ni d’envoi automatique de vos essais.

## Contenu du pack

- `OUVRIR-APPLICATION.html` : application portable, code et styles intégrés.
- `Web-developpement-ln-ia.docx` : guide Word de 26 pages.
- `site/` : application construite, prête pour un hébergement statique.
- `application/` : sources Vite et Bootstrap, versions verrouillées.
- `exemples/` : six exemples, chacun avec une page complète et trois zones de code séparées.
- `schema/` : schéma amélioré en SVG et PNG.
- `site/docs/` : guide, fiche candidat, conducteur et synthèse OCDE.
- `CONTROLES.md` : contrôles réalisés et périmètre de vérification.
- `SOURCES-ET-CREDITS.md` : références et licences des composants.

## Modifier les sources dans VS Code

Installez une version de Node.js compatible avec `application/package.json`. Node.js 24 convient. Ouvrez un terminal dans le dossier `application`.

```sh
npm ci
npm run dev
```

Suivez l’adresse locale indiquée par Vite. Pour vérifier et construire :

```sh
npm test
npm run build
```

La construction écrit `application/dist/`. Pour régénérer également une ouverture portable et les exemples :

```sh
npm run pack
```

Cette commande écrit les résultats dans le dossier voisin `pack/`. Les ressources DOCX et Markdown sont conservées dans `application/public/docs/` et recopiées à chaque construction. Le contenu pédagogique modifiable est dans `application/src/curriculum.json`. La synthèse OCDE se trouve dans `pdf-insights.json` et les sources dans `sources.json`.

## Publier un site statique

Le dossier `site/` fourni est déjà construit. Déposez son contenu chez votre hébergeur, avec `index.html` à la racine de l’emplacement choisi. Après une modification des sources, publiez le contenu de `application/dist/`.

Pour GitHub Pages, placez le contenu construit à la racine de la branche choisie ou dans son dossier `docs`, puis choisissez cette source dans Settings > Pages. Les chemins relatifs permettent de publier sous un sous-dossier de dépôt. Aucune publication GitHub n’est effectuée par ce pack.

Après mise en ligne, vérifiez les huit rubriques, le téléchargement du guide et les images. Complétez, si nécessaire, les métadonnées avec l’URL publique réelle : canonical, og:url, og:image absolue et sitemap. Le titre, la description, la langue, les métadonnées de partage et la description structurée du support sont déjà présents. Les huit rubriques constituent une application unique, pas huit pages SEO indépendantes.

## Votre production finale

Conservez une page HTML utile à votre public, une seule action principale, trois tests réellement exécutés et une correction humaine justifiée. Le cas Roue Libre est fictif. Vous pouvez le remplacer par votre projet personnel.

La rubrique IA propose des prompts à utiliser dans votre outil habituel. Elle n’appelle aucun modèle et ne demande aucune clé API. Le PDF OCDE fourni a servi à une synthèse traduite sur les agents IA. Les concepts HTML, CSS et JavaScript s’appuient sur la documentation technique référencée.

![LN-IA](../../site/assets/logo-ln-ia.png)

# 3 · Organiser la page avec CSS

Modifier les couleurs et la typographie, puis organiser une page qui reste lisible sur un écran étroit.

Présentez votre fiche avec deux couleurs principales, une typographie lisible, des sections espacées et une mise en page qui ne déborde pas sur mobile.

## Vérifier

- Le texte reste lisible et contrasté.
- Les images restent dans le conteneur.
- Aucun contenu ne nécessite un défilement horizontal sur un petit écran.
- Les états de focus sont visibles.

## Correction

Exemple : body utilise une police système, un interligne de 1.6 et un fond clair. main utilise max-width: 760px et margin: auto. Une règle @media (max-width: 600px) réduit le padding du body. Le lien garde un contour visible avec :focus-visible.

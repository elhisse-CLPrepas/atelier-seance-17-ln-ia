![LN-IA](../../site/assets/logo-ln-ia.png)

# 1 · Construire la structure avec HTML

Construire une page lisible avec un titre principal, un paragraphe, une liste et des sections identifiables.

Créez la structure de votre fiche : un titre principal, une introduction de deux phrases, deux sections titrées et une liste.

## Vérifier

- Le sujet est compris dès le titre.
- Les balises sont correctement imbriquées.
- La hiérarchie des titres est logique.
- Le contenu reste compréhensible sans mise en forme.

## Correction

Une structure possible est main, puis header avec h1 et p, puis deux sections avec chacune h2 et p ou ul. Le h1 porte le sujet de la page. Les h2 annoncent deux parties du même niveau. Fermez un élément avant de fermer son parent.

const formulaire = document.querySelector("#accueil");
const saisie = document.querySelector("#prenom");
const message = document.querySelector("#message");
const fiche = document.querySelector("#fiche");

formulaire.addEventListener("submit", (evenement) => {
  evenement.preventDefault();
  const prenom = saisie.value.trim();
  message.textContent = prenom
    ? "Bonjour " + prenom + ", voici les deux points à examiner."
    : "Bienvenue. Voici les deux points à examiner.";
  fiche.hidden = false;
});
![LN-IA](../../site/assets/logo-ln-ia.png)

# 4 · Ajouter une interaction avec JavaScript

Réagir à la soumission d’un formulaire et afficher un texte qui dépend de la saisie.

Ajoutez un accueil personnalisé à votre fiche. Documentez trois tests avec saisie, résultat attendu et résultat observé.

## Vérifier

- Le formulaire fonctionne au clic et avec Entrée.
- Un champ vide produit un message compréhensible.
- Les espaces seuls sont traités comme une saisie vide.
- Une saisie contenant des balises reste du texte.
- La fiche apparaît après l’action du lecteur.

## Correction

Avec Samira, le message commence par Bonjour Samira. Avec une saisie vide ou des espaces, il commence par Bienvenue. Avec <b>Samira</b>, les caractères sont affichés tels quels grâce à textContent. fiche.hidden = false révèle la fiche. Ces tests ne remplacent pas une revue complète du code.

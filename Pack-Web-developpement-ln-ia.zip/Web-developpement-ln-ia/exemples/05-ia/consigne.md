![LN-IA](../../site/assets/logo-ln-ia.png)

# 5 · Construire avec l’IA et contrôler le résultat

Utiliser un assistant pour proposer une page, puis vérifier le contenu et le code avant de conserver une version.

Produisez une page personnelle avec son brief, le prompt utilisé, une liste de tests et une correction humaine justifiée.

## Vérifier

- Le besoin est défini avant la génération.
- Le contenu ne contient pas de promesse non vérifiée.
- L’action principale est précise et fonctionne.
- Les résultats des tests sont consignés.
- La correction humaine est visible et expliquée.

## Correction

Exemple de contrôle : une proposition promettait une révision complète du vélo alors que le contenu ne traite que les pneus et les freins. La version corrigée annonce deux points à examiner. Le lien Lire la fiche de contrôle ouvre la section attendue. Le journal indique la formulation initiale, la correction, sa justification et les tests réellement effectués.

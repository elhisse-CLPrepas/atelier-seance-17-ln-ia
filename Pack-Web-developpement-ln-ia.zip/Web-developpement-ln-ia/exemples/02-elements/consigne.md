![LN-IA](../../site/assets/logo-ln-ia.png)

# 2 · Insérer une image et un lien

Ajouter une image avec un texte alternatif et un lien dont la destination est identifiable.

Ajoutez à votre fiche une illustration utile et un lien principal. Écrivez en une phrase pourquoi ce lien aide le lecteur.

## Vérifier

- L’image s’affiche et son texte alternatif est adapté.
- Le lien a une destination existante.
- Le libellé annonce ce qui sera ouvert.
- Le lien peut être atteint au clavier.

## Correction

Pour le cas fictif Roue Libre : une illustration de vélo peut porter alt="Illustration d’un vélo de profil". Le lien Lire la fiche de contrôle pointe vers #fiche. La section correspondante porte id="fiche". L’action donne accès aux deux points annoncés.

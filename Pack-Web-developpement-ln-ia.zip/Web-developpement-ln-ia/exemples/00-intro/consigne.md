![LN-IA](../../site/assets/logo-ln-ia.png)

# 0 · Comprendre ce que fait le Web

Décrire le rôle du navigateur et du serveur, puis distinguer la structure, le style et le comportement d’une page.

Produisez une fiche de six lignes : quatre étapes d’un échange Web, puis une phrase sur le rôle du navigateur et une sur le rôle du serveur.

## Vérifier

- La requête part du navigateur.
- La réponse revient du serveur.
- HTML, CSS et JavaScript ont des rôles distincts.
- La simulation n’est pas présentée comme un appel réseau réel.

## Correction

Exemple : je demande une adresse. Le navigateur envoie une requête. Le serveur renvoie une réponse. Le navigateur affiche les ressources reçues. Le navigateur interprète la page. Le serveur fournit les ressources demandées lorsqu’elles sont disponibles. Le navigateur peut aussi utiliser son cache.

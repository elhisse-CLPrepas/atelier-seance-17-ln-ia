const observations = [
  "1. Vous saisissez une adresse : le navigateur prépare la demande.",
  "2. Requête HTTP : le navigateur demande une ressource au serveur.",
  "3. Réponse HTTP : le serveur transmet le contenu ou un état d’erreur.",
  "4. Affichage : le navigateur interprète HTML et CSS, puis peut exécuter JavaScript."
];
let etape = 0;
const bouton = document.querySelector("#etape");
const resultat = document.querySelector("#observation");
bouton.addEventListener("click", () => {
  resultat.textContent = observations[etape];
  etape = (etape + 1) % observations.length;
});
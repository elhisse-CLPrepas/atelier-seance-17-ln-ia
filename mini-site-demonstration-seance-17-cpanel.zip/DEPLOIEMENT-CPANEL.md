# Déployer le mini-site validé sur cPanel

URL prévue : https://clprepas.com/mini-site-demonstration-seance-17/

1. Dans cPanel, ouvrir le gestionnaire de fichiers et retrouver la racine
   documentaire du domaine clprepas.com (souvent public_html ; vérifier dans Domaines).
2. Créer le dossier mini-site-demonstration-seance-17 dans cette racine.
3. Si ce dossier contient déjà un site, en conserver une sauvegarde avant remplacement.
4. Téléverser ce ZIP dans le dossier créé, puis l’extraire à cet endroit.
   index.html doit être directement dans mini-site-demonstration-seance-17/,
   à côté de css/, js/ et assets/, sans dossier supplémentaire imbriqué.
5. Supprimer le ZIP téléversé après extraction.
   Vérifier les permissions : dossiers 755 et fichiers 644, notamment index.html.
6. Ouvrir https://clprepas.com/mini-site-demonstration-seance-17/ puis vérifier les images, les deux états du bouton,
   l’agrandissement de l’affiche, les ancres, le clavier et l’affichage mobile.
7. Vérifier les liens vers l’atelier, le dossier Challenge et le carnet :
   ils rejoignent GitHub Pages et demandent une connexion Internet.

Aucune installation, base de données ou configuration PHP n’est nécessaire.
Le mini-site conserve ses ressources locales et peut aussi être ouvert hors ligne
après extraction ; les accès GitHub Pages demandent une connexion.
Le carnet est hébergé sur GitHub Pages : ses données locales restent associées
à ce navigateur et à cette origine. Exporter les traces depuis le carnet.

## Contrôles du paquet

La génération vérifie les chemins locaux et les ancres HTML, la présence des
fichiers et l’intégrité ZIP. Les essais sur l’hébergement cPanel restent à faire
après téléversement. Aucun déploiement cPanel n’est exécuté par ce script.
